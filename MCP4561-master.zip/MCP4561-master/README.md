MCP4561
=======

Arduino library for using  MCP4561 digital potentiometers by Microchip
